import json
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import random
import string

class Player:
    def __init__(self, name, money, owned_cars):
        self.name = name
        self.money = money
        self.owned_cars = owned_cars

class Car:
    def __init__(self, name, value):
        self.name = name
        self.value = value

class Mission:
    def __init__(self, name, reward):
        self.name = name
        self.reward = reward

class ScrollableFrame(tk.Frame):
    def __init__(self, container, *args, **kwargs):
        super().__init__(container, *args, **kwargs)

        self.canvas = tk.Canvas(self, borderwidth=0)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas)

        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

class GameGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Gear Up")
        self.missions = [
            Mission(f"Mission {i+1}", random.randint(100000, 250000000)) for i in range(200)
        ] + [
            Mission(f"Additional Mission {i+1}", random.randint(100000, 250000000)) for i in range(100)
        ]
        self.cars = [
            Car(f"Car {i+1}", random.randint(200000, 150000000)) for i in range(300)
        ] + [
            Car(f"Additional Car {i+1}", random.randint(200000, 150000000)) for i in range(100)
        ]

        # Set the first car to be worth 1 billion
        self.cars[0] = Car("Top Car", 1_000_000_000)
        
        self.player = Player("", 0, set())

        # Player Info
        self.player_frame = tk.Frame(master)
        self.player_frame.pack()

        self.name_label = tk.Label(self.player_frame, text="Enter your name:")
        self.name_label.grid(row=0, column=0, padx=10, pady=10)

        self.name_entry = tk.Entry(self.player_frame)
        self.name_entry.grid(row=0, column=1, padx=10, pady=10)

        self.name_button = tk.Button(self.player_frame, text="Set Name", command=self.set_name)
        self.name_button.grid(row=0, column=2, padx=10, pady=10)

        self.player_info_label = tk.Label(self.player_frame, text="")
        self.player_info_label.grid(row=1, column=0, columnspan=3, padx=10, pady=10)

        # Car Buying
        self.car_frame = ScrollableFrame(master)
        self.car_frame.pack(expand=True, fill=tk.BOTH)

        self.car_label = tk.Label(self.car_frame.scrollable_frame, text="Available cars to buy:")
        self.car_label.grid(row=0, column=0, padx=10, pady=10)

        self.car_buttons = []

        for i, car in enumerate(self.cars):
            car_text = f"{i+1}. {car.name} - ${car.value}"
            car_button = tk.Button(self.car_frame.scrollable_frame, text=car_text, command=lambda c=car: self.buy_car(c))
            car_button.grid(row=i+1, column=0, padx=10, pady=5, sticky="w")
            self.car_buttons.append(car_button)

        # Owned Cars
        self.owned_car_frame = ScrollableFrame(master)
        self.owned_car_frame.pack(expand=True, fill=tk.BOTH)

        self.owned_car_label = tk.Label(self.owned_car_frame.scrollable_frame, text="Owned cars:")
        self.owned_car_label.grid(row=0, column=0, padx=10, pady=10)

        self.owned_car_buttons = []

        # Missions
        self.mission_frame = ScrollableFrame(master)
        self.mission_frame.pack(expand=True, fill=tk.BOTH)

        self.mission_label = tk.Label(self.mission_frame.scrollable_frame, text="Available missions:")
        self.mission_label.grid(row=0, column=0, padx=10, pady=10)

        self.mission_buttons = []

        for i, mission in enumerate(self.missions):
            mission_text = f"{i+1}. {mission.name} - Reward: ${mission.reward}"
            mission_button = tk.Button(self.mission_frame.scrollable_frame, text=mission_text, command=lambda m=mission: self.accept_mission(m))
            mission_button.grid(row=i+1, column=0, padx=10, pady=5, sticky="w")
            self.mission_buttons.append(mission_button)

        self.update_player_info()

        # Save and Load Buttons
        self.save_file_entry = tk.Entry(master)
        self.save_file_entry.pack(side=tk.LEFT, padx=10, pady=10)
        self.save_button = tk.Button(master, text="Save Game", command=self.save_game)
        self.save_button.pack(side=tk.LEFT, padx=10, pady=10)

        self.load_file_entry = tk.Entry(master)
        self.load_file_entry.pack(side=tk.LEFT, padx=10, pady=10)
        self.load_button = tk.Button(master, text="Load Game", command=self.load_game)
        self.load_button.pack(side=tk.LEFT, padx=10, pady=10)

    def set_name(self):
        name = self.name_entry.get().strip()
        if name:
            self.player.name = name
            self.update_player_info()
        else:
            messagebox.showwarning("Empty Name", "Please enter a valid name.")

    def buy_car(self, car):
        if car.name in self.player.owned_cars:
            messagebox.showinfo("Car Owned", f"You already own the {car.name}.")
            return

        result = messagebox.askyesno("Buy Car", f"Do you want to buy the {car.name} for ${car.value}?")
        if result:
            if self.player.money >= car.value:
                self.player.money -= car.value
                self.player.owned_cars.add(car.name)
                self.update_player_info()
                self.update_car_buttons()
                messagebox.showinfo("Car Bought", f"You bought the {car.name}. Your balance: ${self.player.money}")
            else:
                messagebox.showwarning("Not Enough Money", "You don't have enough money to buy this car.")

    def accept_mission(self, mission):
        result = messagebox.askyesno("Accept Mission", f"Do you want to accept the mission: {mission.name}?")
        if result:
            self.player.money += mission.reward
            self.update_player_info()
            messagebox.showinfo("Mission Accepted", f"You accepted the mission: {mission.name}. Reward: ${mission.reward}")

    def sell_car(self, car_name):
        result = messagebox.askyesno("Sell Car", f"Do you want to sell the {car_name} for half its value?")
        if result:
            for car in self.cars:
                if car.name == car_name:
                    sell_value = car.value // 2
                    break
            self.player.money += sell_value
            self.player.owned_cars.remove(car_name)
            self.update_player_info()
            messagebox.showinfo("Car Sold", f"You sold the {car_name} for ${sell_value}. Your balance: ${self.player.money}")

    def update_player_info(self):
        self.player_info_label.config(text=f"Player: {self.player.name}\nMoney: ${self.player.money}")

        # Update owned cars
        for widget in self.owned_car_buttons:
            widget.destroy()

        self.owned_car_buttons = []

        for i, car_name in enumerate(self.player.owned_cars):
            car_button = tk.Button(self.owned_car_frame.scrollable_frame, text=f"{i+1}. {car_name} - Sell", command=lambda c=car_name: self.sell_car(c))
            car_button.grid(row=i+1, column=0, padx=10, pady=5, sticky="w")
            self.owned_car_buttons.append(car_button)

    def update_car_buttons(self):
        for car_button in self.car_buttons:
            car_text = car_button.cget("text")
            car_name = car_text.split(" - ")[0].split(". ")[1]
            if car_name in self.player.owned_cars:
                car_button.config(state=tk.DISABLED)

    def save_game(self):
        filename = self.save_file_entry.get()
        if not filename:
            messagebox.showwarning("Empty Filename", "Please enter a filename.")
            return

        data = {
            "name": self.player.name,
            "money": self.player.money,
            "owned_cars": list(self.player.owned_cars)
        }
        with open(f"{filename}.json", "w") as f:
            json.dump(data, f)
        messagebox.showinfo("Save", "Game saved successfully.")

    def load_game(self):
        filename = self.load_file_entry.get()
        if not filename:
            messagebox.showwarning("Empty Filename", "Please enter a filename.")
            return

        try:
            with open(f"{filename}.json", "r") as f:
                data = json.load(f)
                self.player = Player(data["name"], data["money"], set(data["owned_cars"]))
                self.update_player_info()
                self.update_car_buttons()
        except FileNotFoundError:
            messagebox.showerror("File Not Found", f"The file '{filename}.json' does not exist.")

def main():
    root = tk.Tk()
    app = GameGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
5